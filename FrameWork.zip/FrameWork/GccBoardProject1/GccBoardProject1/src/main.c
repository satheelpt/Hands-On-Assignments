/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * This is a bare minimum user application template.
 *
 * For documentation of the board, go \ref group_common_boards "here" for a link
 * to the board-specific documentation.
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to board_init()
 * -# Basic usage of on-board LED and button
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>
#include <string.h>

#define TEA_CRYPTO_PWD "satheesh"	
#define TEA_CRYPTO_KEY "microchip"	

int Rx_cmplt=0,Rx_cnt=0;
uint8_t Rx_buff[1000];
uint8_t* ret_ptr;

void configure_usart(uint32_t baudrate);
void usart_stream_reset(void);
void usart_stream_write(uint8_t data);
extern uint8_t * Do_TEA_Encryption(uint8_t * data, uint8_t * key);
extern uint8_t * Do_TEA_Decryption(uint8_t * data, uint8_t * key);


#pragma region UART FUNCTIONS

void configure_usart(uint32_t baudrate)
{
	usart_serial_options_t uart_serial_options = {
		.baudrate = baudrate,
		.paritytype = CONF_UART_PARITY,
		.charlength = US_MR_CHRL_8_BIT,
		.stopbits = 0,
	};

	/* Configure the UART console. */
	usart_serial_init((usart_if)CONF_UART, &uart_serial_options);
	usart_stream_reset();
	uart_enable_interrupt(CONF_UART,UART_IER_RXRDY);   //Interrupt reading ready
	NVIC_EnableIRQ(UART1_IRQn);
	memset(Rx_buff,0,1000);
}

void usart_stream_reset(void)
{
	uart_reset((Uart *)CONF_UART);
	uart_enable((Uart *)CONF_UART);	
}

void usart_stream_write(uint8_t data)
{
	usart_serial_putchar((usart_if)CONF_UART, data);
	
		while (!uart_is_tx_buf_empty((Uart *)CONF_UART)) {
		}
	}
void Send_text_UART(unsigned char * text)
{
	int i;
	 for (i = 0; i < strlen(text); i++){
		 usart_stream_write(text[i]);
	 }
	
}
void Send_byte_arr_UART(unsigned char * text,int cnt)
{
	int i;
	for (i = 0; i < cnt; i++){
		usart_stream_write(text[i]);
	}	
}

#pragma endregion UART FUNCTIONS

#pragma region DISPLAY FUNCTIONS

/* Function to display text on OLED display at preferred location */
void Display_text(unsigned char * text,int page,int col)
{
	ssd1306_set_page_address(page);
	ssd1306_set_column_address(col);
	ssd1306_write_text(text);
}

#pragma endregion DISPLAY FUNCTIONS

#pragma region AUTHENTICATION FUNCTION
/*
Function will decrypt  the TEA encrypted data received via serial port sent 
from PC and validate with the stored password.
*/
uint8_t Authenticate()
{		
	//ret_ptr=Do_TEA_Encryption("Satheesh", "microchip");	//used for testing
	
	ret_ptr=Do_TEA_Decryption(Rx_buff, TEA_CRYPTO_KEY);
	if(!strcmp(ret_ptr,TEA_CRYPTO_PWD))
	{		
		return 1;
	}
	else
	{		
		return 0;
	}
}
#pragma endregion AUTHENTICATION FUNCTION

int main (void)
{
	// Initialize system clock
	sysclk_init();
	
	board_init();
	// Initialize UART
	configure_usart(115200);
	
	// Initialize SPI and SSD1306 controller.
	ssd1306_init();
	ssd1306_clear();
	
	Display_text("Waiting for",0,30);
	Display_text("Authentication..",1,25);
	
	while (1) 
	{
		if(Rx_cmplt==1 && Rx_cnt>1)		//Wait for valid serial data
		{
			Rx_cmplt=0;
			
			if(Authenticate())			//validate password 
			{				
				ssd1306_clear();
				Display_text("Welcome",0,30);
				Display_text(ret_ptr,2,29);
				// send serial data
				Send_text_UART("Authenticated..");	
			}
			else
			{
				ssd1306_clear();
				Display_text("Unauthorized Access..",0,0);
				Display_text(ret_ptr,2,29);
				// send serial data
				Send_text_UART("Unauthorized Access..");
			}
			memset(Rx_buff,0,1000);
			Rx_cnt=0;
		}
		if(Rx_cmplt==1 && Rx_cnt<=1)
		{
			Rx_cnt=0;
			memset(Rx_buff,0,1000);
		}
		
		//usart_stream_write('A');
		delay_ms(1000);
	}	
}

//UART1 Interrupt handler
void UART1_Handler() 
{
	
	while( uart_get_status(UART1) & UART_SR_RXRDY) {
		uint8_t received_byte;
		uart_read(UART1, &received_byte);
		Rx_buff[Rx_cnt]=received_byte;
		Rx_cnt++;
	}
	
	Rx_cmplt=1;
}