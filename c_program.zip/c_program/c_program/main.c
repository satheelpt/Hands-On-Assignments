#include<stdio.h>
#include<conio.h>
void swap(int a, int b);
main()
{
	int a, b,idx;
	long int val;
	printf("Enter 32bit Hex value:");
	scanf_s("%x", &val);
	printf("Enter index to be checked:");
	scanf_s("%d", &idx);
	if (Check_set_bit(val, idx))
	{
		printf("%d-th Bit of value is set(1)",idx);
	}
	else
	{
		printf("%d-th Bit of value is clear(0)", idx);
	}
	/*printf("Enter byte value:");
	scanf_s("%d", &a);
	Count_set_bit((unsigned char)a);
	getchar();*/
	/*printf("Enter variable a:");
	scanf_s("%d", &a);
	printf("Enter variable b:");
	scanf_s("%d", &b);
	swap(a, b);*/
}
void swap(int a, int b)
{
	a = a + b;
	b = a - b;
	a = a - b;
	printf("a=%d b=%d", a, b);
	
}
int Count_set_bit(unsigned char byte_val)
{
	int cnt = 0;
	while (byte_val)
	{
		if (byte_val & 1)
		{
			cnt += 1;
		}
		byte_val >>= 1;
	}
	printf("Number of set bits :%d", cnt);
}
int Check_set_bit(long int val, unsigned char index)
{
	int cnt = 0;
	val >>= index;
	if (val & 1){
		return 1;}
	else{
		return 0;}	
}