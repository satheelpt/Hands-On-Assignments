using System;


namespace TeaCrypto
{
	/// <summary>
	/// Summary description for Tea.
	/// </summary>
	public class Tea
	{
        public byte[] Enc_data;
		// Ctor
		public Tea()
		{
		}

		public string EncryptString(string Data, string Key)
		{
			if(Data.Length == 0)
				throw new ArgumentException("Data must be at least 1 character in length.");

			uint[] formattedKey = FormatKey(Key);

			if(Data.Length%2!=0) Data += '\0'; // Make sure array is even in length.		
			byte[] dataBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(Data);

			string cipher = string.Empty;
			uint[] tempData = new uint[2];
            Enc_data = new byte[dataBytes.Length*4 ];
            int cnt=0;
			for(int i=0; i<dataBytes.Length; i+=2)
			{
				tempData[0] = dataBytes[i];
				tempData[1] = dataBytes[i+1];
                
				code(tempData, formattedKey);
                
                byte[] temp = BitConverter.GetBytes(tempData[0]);
                Enc_data[cnt] = temp[0];
                Enc_data[cnt+1] = temp[1];
                Enc_data[cnt+2] = temp[2];
                Enc_data[cnt+3] = temp[3];
                cnt += 4;
                byte[] temp1 = BitConverter.GetBytes(tempData[1]);
                Enc_data[cnt] = temp1[0];
                Enc_data[cnt + 1] = temp1[1];
                Enc_data[cnt + 2] = temp1[2];
                Enc_data[cnt + 3] = temp1[3];
                cnt += 4;
				cipher += Util.ConvertUIntToString(tempData[0]) + Util.ConvertUIntToString(tempData[1]);
			}
            byte[] dataBytes1 = System.Text.ASCIIEncoding.ASCII.GetBytes(cipher);
            

			return cipher;
		}

		public string Decrypt(string Data, string Key)
		{
			uint[] formattedKey = FormatKey(Key);

			int x = 0;
			uint[] tempData = new uint[2];
			byte[] dataBytes = new byte[Data.Length / 8 * 2];
			for(int i=0; i<Data.Length; i+=8)
			{
				tempData[0] = Util.ConvertStringToUInt(Data.Substring(i, 4));
				tempData[1] = Util.ConvertStringToUInt(Data.Substring(i+4, 4));
				decode(tempData, formattedKey);
				dataBytes[x++] = (byte)tempData[0];
				dataBytes[x++] = (byte)tempData[1];
			}

			string decipheredString = System.Text.ASCIIEncoding.ASCII.GetString(dataBytes, 0, dataBytes.Length);
			if(decipheredString[decipheredString.Length - 1] == '\0') // Strip the null char if it was added.
				decipheredString = decipheredString.Substring(0, decipheredString.Length - 1);
			return decipheredString;
		}

		public uint[] FormatKey(string Key)
		{
			if(Key.Length == 0)
				throw new ArgumentException("Key must be between 1 and 16 characters in length");

			Key = Key.PadRight(16,' ').Substring(0, 16); // Ensure that the key is 16 chars in length.
			uint[] formattedKey = new uint[4];

			// Get the key into the correct format for TEA usage.
			int j = 0;
			for(int i=0; i<Key.Length; i+=4)
				formattedKey[j++] = Util.ConvertStringToUInt(Key.Substring(i, 4));

			return formattedKey;
		}

        public  string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public  string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

		#region TEA_Algorithm

		public void code(uint[] v, uint[] k)  
		{              
			uint v0 = v[0];
			uint v1= v[1];
			uint sum = 0;   
			uint delta=0x9e3779b9;
			uint n=32;
            uint k0 = k[1], k1 = k[1], k2 = k[2], k3 = k[3];
			while (n-- > 0) 
			{ 
                sum += delta;             
                v0 += (v1 << 4) + k[0] ^ v1 + sum ^ (v1 >> 5) + k[1];
                v1 += (v0 << 4) + k[2] ^ v0 + sum ^ (v0 >> 5) + k[3];   

			} 

			v[0]=v0; 
			v[1]=v1; 
		}

		public void decode(uint[] v, uint[] k)  
		{
			uint n=32;
            uint sum = 0xC6EF3720;
			uint v0=v[0];
			uint v1=v[1];
			uint delta=0x9e3779b9;
            uint k0 = k[1], k1 = k[1], k2 = k[2], k3 = k[3];
			
			while (n-- > 0) 
			{
                v1 -= ((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >> 5) + k[3]);
               
                v0 -= ((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >> 5) + k[1]);
                sum -= delta;
                
			}

			v[0]=v0; 
			v[1]=v1; 
		}

		#endregion
	}
	
}

