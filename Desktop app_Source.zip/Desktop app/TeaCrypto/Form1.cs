using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO.Ports;
using System.Text;
using System.Threading;
namespace TeaCrypto
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox txtData;
		private System.Windows.Forms.TextBox txtKey;
		private string cipher;
        private Label lbl_com;
        private Button btn_Connect;
        private Button button3;
        private ComboBox list_com;
        private IContainer components;
        private Label lbl_status;
       
        SerialPort oSerialPort;
        private TextBox txt_pwd;
        StringBuilder rxd=new StringBuilder();
        private Label label3;


        Tea t = new Tea();


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.button1 = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lbl_com = new System.Windows.Forms.Label();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.list_com = new System.Windows.Forms.ComboBox();
            this.lbl_status = new System.Windows.Forms.Label();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(28, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Encrypt";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(27, 259);
            this.txtData.MaxLength = 512;
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtData.Size = new System.Drawing.Size(272, 94);
            this.txtData.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(12, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password to be Encrypted:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(12, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Key:";
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(42, 132);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(244, 20);
            this.txtKey.TabIndex = 6;
            this.txtKey.Text = "microchip";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(175, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(124, 32);
            this.button2.TabIndex = 5;
            this.button2.Text = "Decrypt";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_com
            // 
            this.lbl_com.AutoSize = true;
            this.lbl_com.Location = new System.Drawing.Point(3, 46);
            this.lbl_com.Name = "lbl_com";
            this.lbl_com.Size = new System.Drawing.Size(53, 13);
            this.lbl_com.TabIndex = 10;
            this.lbl_com.Text = "COM Port";
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(202, 43);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(97, 23);
            this.btn_Connect.TabIndex = 8;
            this.btn_Connect.Text = "Connect";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(79, 78);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(157, 32);
            this.button3.TabIndex = 11;
            this.button3.Text = "Encrypt and Send";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // list_com
            // 
            this.list_com.FormattingEnabled = true;
            this.list_com.Location = new System.Drawing.Point(62, 43);
            this.list_com.Name = "list_com";
            this.list_com.Size = new System.Drawing.Size(121, 21);
            this.list_com.TabIndex = 12;
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.ForeColor = System.Drawing.Color.DarkOrange;
            this.lbl_status.Location = new System.Drawing.Point(3, 9);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(199, 15);
            this.lbl_status.TabIndex = 13;
            this.lbl_status.Text = "Select COM port and click connect..";
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(42, 180);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.Size = new System.Drawing.Size(244, 20);
            this.txt_pwd.TabIndex = 14;
            this.txt_pwd.Text = "satheesh";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(12, 234);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 22);
            this.label3.TabIndex = 15;
            this.label3.Text = "TEA procesed data";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(321, 413);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_pwd);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.list_com);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.lbl_com);
            this.Controls.Add(this.btn_Connect);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtKey);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "TEA Crypto test App";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
            
            //show list of valid com ports
            foreach (string s in SerialPort.GetPortNames())
            {
                list_com.Items.Add(s);
            }  
            if(list_com.Items.Count==0) 
            {
                lbl_status.Text = "No Com ports available";
            }
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
            if (txt_pwd.Text != "" || txtKey.Text != "")
            {
               
                cipher = t.EncryptString(txt_pwd.Text, txtKey.Text);
                
                txtData.Text = cipher;
                txtData.ReadOnly = false;
                button2.Enabled = true;
                button1.Enabled = true;
                txtData.Focus();
            }
            else
            {
                MessageBox.Show("Please Enter data in fields..");
            }
		}

        private void button2_Click(object sender, System.EventArgs e)
        {
            if (txtData.Text != "" || txtKey.Text != "")
            {
                
               
                txtData.Text = t.Decrypt(cipher, txtKey.Text);
                txtData.ReadOnly = false;
                button2.Enabled = true;
                button1.Enabled = true;
                txtData.Focus();
            }
            else
            {
                MessageBox.Show("Please Enter data in fields..");
            }
        }

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            try
            {
               
                oSerialPort = new SerialPort(list_com.SelectedItem.ToString(), 115200, Parity.None, 8, StopBits.One);
                oSerialPort.DtrEnable = true;
                oSerialPort.RtsEnable = true;
                oSerialPort.DataReceived += oSerialPort_DataReceived;
                oSerialPort.Open();
                lbl_status.Text = "Connection Success";
            }
            catch (Exception ex)
            {
                lbl_status.Text = "Connection Failed";
               
            }
        }
        private void oSerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
               
                    rxd.Append(oSerialPort.ReadExisting());
                    Thread.Sleep(200);
                    rxd.Append(oSerialPort.ReadExisting());

                    MessageBox.Show(rxd.ToString(), "Rxd from SAM4s..");
                    rxd.Remove(0,rxd.Length);
            }
            catch (Exception ex)
            {
               
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (oSerialPort !=null)
            {
                button1_Click(null,null);
                oSerialPort.Write(t.Enc_data, 0, t.Enc_data.Length);
                
            }
            else
            {
                MessageBox.Show("Connect to COM port first..");
            }
        }

      
	}
}
